//
//  PersonViewController.swift
//  task13
//
//  Created by student on 2018/12/17.
//  Copyright © 2018年 guoxiaohan. All rights reserved.
//

import UIKit
import  Alamofire
class PersonViewController: UIViewController {

    @IBOutlet weak var gender: UILabel!
    @IBOutlet weak var no: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var image: UIImageView!
    var person:[String:String]?
    override func viewDidLoad() {
        super.viewDidLoad()
        name.text = person?["stuName"]
        gender.text = person?["stuGender"]
        no.text = person?["stuNo"]
        // Do any additional setup after loading the view.
        if let imagePath = person?["imagePath"] {
            if let url = URL(string: "http://10.0.1.2/\(imagePath)") {
                AF.request(url).responseData { (response) in
                    self.image.image = UIImage(data: response.data!)
                }
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
