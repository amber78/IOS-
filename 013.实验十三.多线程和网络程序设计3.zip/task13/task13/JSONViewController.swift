//
//  JSONViewController.swift
//  task13
//
//  Created by student on 2018/12/17.
//  Copyright © 2018年 guoxiaohan. All rights reserved.
//

import UIKit
import Alamofire
class JSONViewController: UIViewController {
    let citise = ["北京": 101010100, "上海": 101020100, "天津": 101030100, "重庆": 101040100, "哈尔滨": 101050101, "长春": 101060101, "沈阳": 101070101, "呼和浩特": 101080101, "石家庄": 101090101, "太原": 101100101, "西安": 101110101, "济南": 101120101, "乌鲁木齐": 101130101, "拉萨": 101140101, "西宁": 101150101, "兰州": 101160101, "银川": 101170101, "郑州": 101180101, "南京": 101190101, "武汉": 101200101, "杭州": 101210101, "合肥": 101220101, "福州": 101230101, "南昌": 101240101, "长沙": 101250101, "贵阳": 101260101, "成都": 101270101, "广州": 101280101, "昆明": 101290101, "南宁": 101300101, "海口": 101310101, "香港": 101320101, "澳门": 101330101, "台北县": 101340101]
    let url = URL(string: "http://10.0.1.2/pic.php?id=1")!
    var persons:[[String:String]]?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func loadWithURL(_ sender: Any) {
        if let data = try? Data(contentsOf: url) {
            if let json = try? JSONSerialization.jsonObject(with: data, options: .allowFragments) as! [[String: String]] {
                for person in json {
                    print("name:\(person["stuName"] ?? "")")
                }
            }
        }
        
    }
    
    @IBAction func loadWithSession(_ sender: Any) {
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if let json = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [[String: String]] {
                self.persons = json
                DispatchQueue.main.async {
                    self.performSegue(withIdentifier: "ShowPersonList", sender: self)
                }
            }
        }
        task.resume()
    }
    @IBAction func loadWithAF(_ sender: Any) {
        
        AF.request(url).responseJSON { (response) in
            let json = response.value as! [[String: String]]
            self.persons = response.value as? [[String:String]]
            DispatchQueue.main.async {
                self.performSegue(withIdentifier: "ShowPersonList", sender: self)
            }
        }

        
    
    }
    
    

     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowPersons" {
            if let secVC = segue.destination as? PersonsTableViewController {
                secVC.persons = self.persons
            }
        }
    }
    

}
