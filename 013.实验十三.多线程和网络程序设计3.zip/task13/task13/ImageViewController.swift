//
//  ViewController.swift
//  task13
//
//  Created by student on 2018/12/17.
//  Copyright © 2018年 guoxiaohan. All rights reserved.
//

import UIKit
import Alamofire
class ImageViewController: UIViewController {

    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var imageView2: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func loadWithURL(_ sender: Any) {
        DispatchQueue.global().async {
            if let url = URL(string: "http://img.hb.aicdn.com/6f6f6c1bf60e381326b26777bb91a2b2d323c4a917bb7-17RLXU_sq320"),let data = try? Data(contentsOf: url) {
                DispatchQueue.main.async {
                    self.imageView1.image = UIImage(data: data)
                }
            }
        }
    }
    
    @IBAction func loadWithSession(_ sender: Any) {
        DispatchQueue.global().async {
            if let url = URL(string: "http://img.hb.aicdn.com/6d1fe10fd0a19bc9f0bd4a39a306e4914c1b4b233fb9d-vmLggG_sq320") {
                let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                    if error == nil {
                        DispatchQueue.main.async {
                            self.imageView2.image = UIImage(data: data!)
                        }
                    }
                }
                task.resume()
            }
        }
    }

    
    @IBAction func loadWithAF(_ sender: Any) {
         if let url = URL(string: "http://img.hb.aicdn.com/6d1fe10fd0a19bc9f0bd4a39a306e4914c1b4b233fb9d-vmLggG_sq320") {
            AF.request(url).responseData { (response) in
                self.imageView2.image = UIImage(data: response.data!)
            }
        }
    }
}

